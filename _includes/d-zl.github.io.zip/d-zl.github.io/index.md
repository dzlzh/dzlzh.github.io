---
layout: home
---

<div class="index-content wiki">
    <div class="section">
        <ul class="artical-cate">
            <li class="on"><a href="/"><span>Wiki</span></a></li>
            <li style="text-align:center"><a href="/blog"><span>Blog</span></a></li>
            <li style="text-align:right"><a href="/project"><span>Project</span></a></li>
        </ul>

        <div class="cate-bar"><span id="cateBar"></span></div>


       {% include wiki.md %}

    </div>
    <div class="aside">
    </div>
</div>
