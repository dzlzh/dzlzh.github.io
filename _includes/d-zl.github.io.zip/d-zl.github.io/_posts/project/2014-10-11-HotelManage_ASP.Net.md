---
layout: post
title: 酒店管理系统（B/S）
category: project
description: 没错这又是一个渣成翔一样的代码，(￣.￣)  而且还是个半成品。
--- 

酒店管理系统（B/S）
------------------

> 没错这又是一个渣成翔一样的代码，(￣.￣)  而且还是个半成品。

[HotelManage_ASP.Net][1]大学的时候做的第一个B/S的项目。

####开发工具

Visual Studio 2012 + SQL Server 2012

####软件环境

ASP.Net + SQL Server

####项目介绍

帮助酒店管理者及时、全面地了解经营信息，做出更加准确的决策，从而有效地提高酒店的经营效益。


[1]:https://github.com/D-ZL/HotelManage_ASP.Net


