---
layout: post
title: 新闻管理系统（B/S）
category: project
description:  这还是一个渣成翔一样的代码，(￣.￣)  而且这也是个半成品。
--- 

新闻管理系统（B/S）
------------------

> 这还是一个渣成翔一样的代码，(￣.￣)  而且这也是个半成品。

[NewsRelease_ASP.Net][1]大学的时候做的第三个B/S的项目。

####开发工具

Visual Studio 2012 + SQL Server 2012

####软件环境

ASP.Net + SQL Server

####项目介绍

系统主要实现对新闻的分类，管理，检索，浏览等一系列问题，从而为用户提供一个美观，大方，快速的前台新闻阅读界面。


[1]:https://github.com/D-ZL/NewsRelease_ASP.Net

