---
layout: post
title: 教务管理系统（C/S）
category: project
description:  这又是一个渣成翔一样的代码
---

教务管理系统（C/S）
------------------

> 这又是一个渣成翔一样的代码

[EducationalAdministration_CSharp][1]这是我在上大学的时候写的第二个项目，而且还是个半成品。(￣▽￣)!!!

####开发工具

Visual Studio 2012 + SQL Server 2012

####功能

(￣.￣) 忘记了！！！



[1]:ttps://github.com/D-ZL/EducationalAdministration_CSharp


