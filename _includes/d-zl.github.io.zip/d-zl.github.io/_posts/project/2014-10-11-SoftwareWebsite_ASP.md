---
layout: post
title: 软件技术专业网站（B/S）
category: project
description:  (￣▽￣) 这个项目还是比较完整的一个项目，因为是要参加一个比赛所以文档比较完整。
--- 

软件技术专业网站（B/S）
----------------

> (￣▽￣) 这个项目还是比较完整的一个项目，因为是要参加一个比赛所以文档比较完整。

[SoftwareWebsite_ASP.Net][1]这是自己写的第一个比较完整的网站。

####开发工具

Visual Studio 2012 + SQL Server 2012

####软件环境

ASP.Net + SQL Server

####项目介绍

网站主要用来宣传软件专业和服务与我校软件专业的在校生。


[1]:https://github.com/D-ZL/SoftwareWebsite_ASP.Net

